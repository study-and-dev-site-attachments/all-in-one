1. Installation:
================
There is no "setup" executable or shell script to install the software.
We're going to assume you're experienced Java developers. Because the
software is completely written in the Java programming language, all
you need to do is to copy the supplied jar files to your classpath (or
modify your class path to include the supplied jar files). For information
about what jar files should be included, check the programming guide
(in the 'doc' directory) for details.

To run the demo, refer to the 'run.bat' batch file at the NetClue/Clue4.2
directory. You may need to modify it to match your Java settings.

Since the 4.0 release, we added facilities to deal with environment
settings. When started up, Clue WBC will look for the 'clue.properties'
file to read initial values to setup its own environment. Therefore, if
you copy Clue's jar file to a new directory, remember to copy
'clue.properties' to the same directory.

In the 'clue.properties' file, you can tell Clue WBC where to find its
image files (specified by the image_dir entry) and where to store
user profiles (specified by the user_dir entry). For details, you should
check documents in the 'doc' directory.

We highly recommend you to review the documents in the 'doc' directory
(use ./doc/index.html as the starting point). It will help you to
understand the design pholosophy of Clue WBC and use the software more
effectively.



2. Release notes:
=================
4.2
---
Each time we release a new version, there are always two types of changes:
the visible and invisible parts. The visible part is new features added.
Below is a brief list of new features:

* Support for XSLT. 
* Printing 
* Javascript v1.5 
* Support for JMF (Java Media Framework) and Flash (by JMF). 
* File upload. 
* Enhanced link traversal. 
* "disabled" and "readonly" attributes of form elements are supported. 
* "onFocus" and "onBlur" attributes are supported. 
* Enhanced applet security (check http://tiki-lounge.com/~ben/msie_bug/ 
  for details). 

The invisible part is the structural change we made to make Clue browser
more efficient and stable. It won't be noticed right away, but it does
improve the overall quality of the software.

Of course, there are always bug fixes. We also modified the rendering
engine to match the rendering outcomes of IE when the rendering behavior
is not well defined by any web standards.


4.1
---
* Support for XML/XHTML documents. 
* Support for namespaces. 
* Support for SSL. 
* API of the script language framework published. 
* The com.netclue.dom.base package: foundataion of DOM and Javascript 
  implementation. 
* New API to access and interact with submit forms. 
* New API to listen to message events. 
* New API to enumerate hyperlinks. 
* Standard-compliant extensions to display menu, tree views and tab panels
  in XML/XHTML documents [PET: Presentation Extension Tags] 
* Importing custom UI components to XML/XHTML documents [PET: Presentation 
  Extension Tags]. 
* Bookmark API 
* New API (PopupCallback) to listen to mouse right click. 


4.0
---
The design goals of Clue 4.0 are 1) support popular CSS2 features,
2) enhanced Javascrpt support, 3) adding new features without hurting
performance or using more memory.

Thanks to feedback from developers, we've made some changes to APIs.
Clue 4.0 is also ready for XML, and some API changes are the direct result
of that. XML support will be 'add-on' to Clue 4.0, and it will be available
soon.


3.1
---
New features:
* HTTP 1.1
* Supports BMP and PNG
* Web Proxy
* Server authentication
* Improved CSS capability, JavaScript and rendering.
* New UI components available: HTMLDialog and CScrollPane.

3.0
---
The design goal of 3.0 is to support CSS. With CSS implemented in Clue
browser, now the major browser features have been supported. CSS adds
more features to a browser. On the other hand, it takes a lot more
computing power to process CSS attributes and apply them to the layout.
So one of the major issue is to do all the CSS stuff, and do it fast
enough. We believe we've achieved the goal. The 3.0 release is at least
running at the same speed as version 2.6 which is very fast compared to
other Java browsers, even though it does much more things. Also, the
layout engine is further refined.

2.6
---
Here are the new improvements:
* Supports streamline parsing.
* Allows HTML files to load in-memory objects by the "memory" protocol.
* Supports printing in JDK 1.2.
* Improved JavaScript support. 

2.5
---
Even the verson number looks like just an upgrade from the previous
release, this release do have many major and important improvements like:

1. Support of DOM (Document Object Model) level 1 and JavaScript 1.2.
2. Browsing history.
3. Improvement on speed.

We've also refined the layout engine quite a bit. The behavior now
looks very close to NS/IE browsers. Actually, in some cases Clue browser
does a better job than Netscape browser.

2.2
---
We've done some bug fixes in this release. Below is a brief listing
of bug fixes:

1. Text wraps around images or tables. Algorithm used in previous release
   does a fine job, but may look awkward if the grographic layout gets
   really complicated. The new alrorithm should handle any kinds of cases
   which can happen in HTML.
2. Table layout is further refined to handle situations where HTML authors
   specify inconsistent width constraints.
3. Fix a bug in HTML forms.
4. Frames are improved in many ways. The easist one to notice is scrolling.
   Now no more flickering to scroll frames.
5. Missing images. Some images may never show up in the previous release.
   The problem is gone.

Besides bug fixes, we also perform some architectural changes to 2.2. The
purpose is to prepare Clue WBC to support DOM and Javascript. Users may
not notice the effects of such changes except for some speed improvement.


2.1
---
The major improvement of this release over previous version (2.0)
is speed. We have done quite substantial internal buffer
consolidations. The result is less memory copy operations and
the rendering process has been speed up quite a bit. We have also done
some improvements on table layout. The rendering quality of Clue
2.1 has come really close to rival NS/IE browsers.



3. Trouble shooting:
====================
Remember to check back our online FAQ if you have any questons. You
can also email to info@netcluesoft.com.

Bug reports are certainly welcome. Please provide sample codes (HTML
or Java) to reproduce problems. Thanks.





