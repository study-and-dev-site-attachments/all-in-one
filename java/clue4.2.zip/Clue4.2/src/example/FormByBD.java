
import  java.awt.*;
import  java.awt.event.*;
import  com.netclue.dom.base.BDElement;
import  com.netclue.dom.base.BDText;
import  com.netclue.xml.gui.XContainer;
import  org.w3c.dom.*;

public  class  FormByBD  extends Panel
{

  public  FormByBD()  {
    setLayout(new java.awt.BorderLayout());
    setBackground( Color.lightGray );
    XContainer  xc = new XContainer();
    add( xc );

    BDElement  html = createForm();
    xc.setDocumentRoot( html, "_top", "text/html" );
  }


  BDElement  createForm()  {
    //  create a submit form
    BDElement  form = BDElement.createElement( "form" );
    form.setAttribute("action", "http://search.yahoo.com/bin/search");
    BDElement  txfield = BDElement.createElement( "input" );
    txfield.setAttribute("name", "p");

    BDElement  submit = BDElement.createElement( "input" );
    submit.setAttribute("type", "submit");

    form.appendChild( txfield );
    form.appendChild( submit );

    // create <body> and its children
    BDElement  body = BDElement.createElement( "body" );
    BDText  txt1 = new BDText("Let's do a search on yahoo");
    BDElement  br = BDElement.createElement( "br" );
    BDText  txt2 = new BDText("Input keywords: ");
    body.appendChild( txt1 );
    body.appendChild( br );
    body.appendChild( txt2 );
    body.appendChild( form );

    BDElement  html = BDElement.createElement("html");
    html.appendChild( body );

    return  html;
  }


  static public void main(String args[]) {
    class DriverFrame extends Frame { //java.awt.JFrame {

      public DriverFrame()  {
        addWindowListener(new java.awt.event.WindowAdapter() {
	  public void windowClosing(java.awt.event.WindowEvent event) {
	    dispose();	  // free the system resources
	    System.exit(0); // close the application
	  }
	});

	this.setLayout(new java.awt.BorderLayout());
	this.setTitle("Clue Web Browser 4.1");
	this.setSize(700,600);

        FormByBD  ccp = new FormByBD();
	this.add( ccp );
      }
    }

    new DriverFrame().show();
  }
}
