import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import java.io.IOException;
import java.net.URL;
import javax.swing.*;
import com.netclue.xml.gui.XContainer;

public class MiniBrowser extends JFrame {

  XContainer htmlText;
  JTextField   txIn;

  public MiniBrowser() {
    JPanel p = new JPanel( new BorderLayout() );
    p.add( new JLabel("Where to go: "), BorderLayout.WEST );
    txIn = new JTextField();

    txIn.addActionListener( new ActionListener()  {
      public  void  actionPerformed(ActionEvent e)  {
        try  {
          // get user's input from the text field, and pass it to
          // XContainer to render it
          URL  url = new URL( txIn.getText() );
          htmlText.setPage( url );
        }
        catch (IOException urle)  {
          // dump the content to see what's going on
          urle.printStackTrace();
        }
      }
    });
    p.add( txIn, BorderLayout.CENTER );

    htmlText = new XContainer();

    Container  c = getContentPane();
    c.setLayout(new java.awt.BorderLayout());
    c.add( p, BorderLayout.NORTH);
    c.add( htmlText, BorderLayout.CENTER);

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent event) {
        // close the application
        System.exit(0);
      }
    });
  }


  static public void main(String args[]) {
    JFrame  top = new MiniBrowser();
    top.setSize(640,600);
    top.show();
  }
}
