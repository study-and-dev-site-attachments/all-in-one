import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.URL;
import javax.swing.*;
import com.netclue.widget.ProgressSign;
import com.netclue.xml.gui.XContainer;
import com.netclue.xml.gui.event.*;

public class MiniBrowser2 extends JFrame {

  XContainer    htmlText;
  JTextField    txIn;
  JLabel        statusLabel;
  ProgressSign  progSign;

  public MiniBrowser2() {
    htmlText = new XContainer();
    JPanel  statusPanel = createStatusPanel();
    JPanel  northPanel = createNorthPanel();

    Container  c = getContentPane();
    c.setLayout(new java.awt.BorderLayout());

    c.add( northPanel, BorderLayout.NORTH);
    c.add( htmlText, BorderLayout.CENTER);
    c.add( statusPanel, BorderLayout.SOUTH );

    htmlText.addDocListener( new DocListener()  {
      public  void  handleDocumentEvent(DocEvent e)   {
        if (e.getType() == DocEvent.DOCUMENT_START_LOADING)
          progSign.start();
        else
          // Not a start loading event. Whether the document is loaded successfully or
          // not, we should stop the progress sign right here.
          progSign.stop();
      }
    });

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent event) {
      // close the application
        System.exit(0);
      }
    });
  }


  JPanel  createNorthPanel()  {
    JPanel  jp = new JPanel( new BorderLayout() );

    jp.add( new JLabel("Where to go: "), BorderLayout.WEST );
    txIn = new JTextField();

    txIn.addActionListener( new ActionListener()  {
      public  void  actionPerformed(ActionEvent e)  {
        try  {
          // get user's input from the text field, and pass it to
          // XContainer to render it
          URL  url = new URL( txIn.getText() );
          htmlText.setPage( url );
        }
        catch (IOException urle)  {
          // dump the content to see what's going on
          urle.printStackTrace();
        }
      }
    });
    jp.add( txIn, BorderLayout.CENTER );

    progSign = createProgressSign();
    jp.add( progSign, BorderLayout.EAST );

    return  jp;
  }


  JPanel  createStatusPanel()  {
    JPanel  jp = new JPanel( new BorderLayout() );
    JLabel  l0 = new JLabel("Status: ");
    statusLabel = new JLabel();

    // listen to the BrowserMessageEvent and dump the message to 'statusLabel'
    htmlText.addBrowserMessageListener( new BrowserMessageListener()  {
      public  void  receiveMessage(BrowserMessageEvent e)  {
        statusLabel.setText( e.getMessage() );
      }
    });

    jp.add( l0, BorderLayout.WEST );
    jp.add( statusLabel, BorderLayout.CENTER );

    return  jp;
  }


  ProgressSign  createProgressSign()  {
    ProgressSign  ps = new ProgressSign();
    Toolkit  tkit = getToolkit();
    try  {
      MediaTracker  tracker = new MediaTracker(this);
      Image  images[] = new Image[15];
      // replace the following with your own image path
      String  imgPath = "file:c:/nc/j2/img/PSign";

      for(int k = 0; k < images.length; k++)  {
        images[k] = tkit.getImage(new URL(imgPath + k + ".jpg"));
        tracker.addImage(images[k], k);
      }

      tracker.waitForAll();
      ps.setImages(images);
    }
    catch(Exception ex) {}

    return  ps;
  }


  static public void main(String args[]) {
    JFrame  top = new MiniBrowser2();
    top.setSize(640,600);
    top.show();
  }
}
